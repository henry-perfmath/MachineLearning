09/08/2020:

we used to load mnist data either online or from saved dir data as follows:

from sklearn.datasets import fetch_mldata
mnist = fetch_mldata('MNIST original', '../data')

However, sklearn has stopped supporting fetch_mldata after 0.21, with an alternative using either datasets package
or fetch_openml package. However, these two approaches only load a small subset of the mnist dataset. For example,

datasets package only loads 1797 images out of 70k total from the original mnist data:

====
digits type:  <class 'sklearn.utils.Bunch'>
digits shape:  (1797, 8, 8)
====

The openml example loads the full dataset of 70k images as shown below, but it does not offer to save data to local
to save time for future runs:

====
(70000, 784)
====

In fact, one workaround is to use the, which can be set up by using python-mnist (https://pypi.org/project/python-mnist/)
and running the following command:

$python3 install python-mnist

All examples in this chapter have been modified to use python-mnist. The mnist data has been saved to data/mldata as 4 ubyte files.
Each example now loads the full mnist data as follows, with the help of a local python utility script named ml_util.py:

------
import ml_util as util
data_dir = '../data/mldata'
mnist = util.fetch_mnist(data_dir)
------

This workaround should remedy the inconvenience caused by the de-support of fetch_mldata since sklearn 0.23.