'''
Created on Sep 8, 2020

@author: henryliu
'''

from mnist import MNIST
import numpy as np
from sklearn.utils import Bunch

def fetch_mnist(data_dir):
    #mnist_data = MNIST('../data/mldata')
    mnist_data = MNIST(data_dir)
    print('type of mnist_data', type(mnist_data))
    # load
    x_train, y_train = mnist_data.load_training() #60000 samples list of list
    x_test, y_test = mnist_data.load_testing()    #10000 samples list
    
    # convert from list to array
    x_train = np.asarray(x_train).astype(np.float32)
    y_train = np.asarray(y_train).astype(np.int32)
    x_test = np.asarray(x_test).astype(np.float32)
    y_test = np.asarray(y_test).astype(np.int32)
    
    # combine. no need to construct mnist.data and mnist.target
    data = np.append(x_train, x_test, axis = 0)
    target = np.append(y_train, y_test, axis = 0)
    mnist = Bunch(data=data, target=target) # 'data' and property
    
    return mnist