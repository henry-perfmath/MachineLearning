'''
Created on Aug 19, 2019

@author: henryliu
'''

from pandas.plotting import scatter_matrix
from sklearn import datasets

import matplotlib.pyplot as plt
import pandas as pd


#%matplotlib inline
plt.style.use('ggplot')

# Load some data
iris = datasets.load_iris()
iris_df = pd.DataFrame(iris['data'], columns=iris['feature_names'])
iris_df['species'] = iris['target']

scatter_matrix(iris_df, alpha=0.2, figsize=(10, 10), c = 'green')
plt.show()

scatter_matrix(iris_df, alpha=0.2, figsize=(10, 10), diagonal='kde')
plt.show()