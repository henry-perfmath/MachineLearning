import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
 
x = np.linspace (0.001, 0.999, 200)

y = -np.log(x)
y1 = -np.log (1-x)
plt.plot (x, y, label = r'$-log(p)$')
plt.plot (x, y1, label = r'$-log(1-p)$')
plt.xlabel("probability")
plt.plot([0.5, 0.5], [0, 9], color ='r')
plt.ylabel(r'$-log(p) \ or -log(1-p)$')

#plt.text(-3.8, 0.83, r'$\sigma(t) = 1/(1 + e^{-t})$', fontsize=12)
#plt.tick_params(direction='in', length=3, width=1, colors='k')
plt.xticks(np.arange(0, 1, 0.1))

#plt.xlim ([-5, 5])
#plt.ylim ([0, 1])
#plt.title("logistic function")
plt.grid(True)
plt.legend(loc = "upper right", frameon=False)
plt.show()
